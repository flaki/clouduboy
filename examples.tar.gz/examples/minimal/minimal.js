"use strict";

// Initialize MicroCanvas
let game = new MicroCanvas();


// Define your globals and variables holding your assets here
//let gfxFoo;
//let sfxBar;
//let myVar;
//const myConst;


// Load graphics, sounds assets and initialize variables here
game.setup(function(game) {
});


// More globals
let moreVars = "foo";


// Main game loop code goes here
game.loop(function() {
  // Define local variables
  //let x,y;

  // Clear display
  //game.clear();

  // Add text
  //game.drawText("Hello World!", x,y, 3);

  // Draw and clear sprites
  //game.clearImage(gfxFoo, x,y);
  //game.drawImage(gfxFoo, x,y);
});

console.log("MicroCanvas initialized");
